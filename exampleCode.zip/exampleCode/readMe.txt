[PHP 8]
	[class]
	Obecná logika

		[db]
		Databáze

		[func]
		Podpůrné funkce
	
		[Sec]
		Zabezpečení

		[Variables]
		Proměnné

[Css]
Styly

[Img]
Grafika

[js]
Javascript

[Section]
Sekce webu

[.htaccess]
Web soubor nemá. Naistaloval jsem Windows 11 a rozladilo se mi nastavení. Podařilo se mi opravit v php.ini SESSION, htaccess však nikoliv

[Web]
Web je responsivní.
Jsou použity styly CSS3
Web je kódován pomocí HTML5
Web používá vlastní architekturu

[MySQL]
	[Database]
	seznam
	
	[Table]
	people

		[Table::People]
		Id: Increment
		firstName: varchar 50
		lastName: varchar 50
		phone: int 50
		mail: varchar 50
		note: text
		date: datetime
		code: varchar 50
		screen: int 2

