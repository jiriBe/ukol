<span class="copyLeft">&copy;</span> (CopyLeft) <?php echo date("Y") > 2022 ? '2021 - ' . date("Y") : date("Y") ?>, Jiří
Beke, +420 776 03 06 02