<?php

namespace class\variables;

class OutputData {

    public $firstName;
    public $lastName;
    public $note;
    public $phone;
    public $msg;
    public $stop;
    public $email;
    public $title;
    public $keywords;
    public $description;
    public $include;
    public $result;
    public $css;
    public $cssIcon;
    public $number;
    public $myCode;
    public $string;

}