<?php

namespace class\variables;

class InputData {

    public $firstName;
    public $lastName;
    public $phone;
    public $email;
    public $note;
    public $userAgent;
    public $code;

}